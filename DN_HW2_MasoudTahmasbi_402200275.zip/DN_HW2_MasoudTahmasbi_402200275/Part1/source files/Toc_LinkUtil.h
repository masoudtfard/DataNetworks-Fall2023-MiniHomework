#ifndef __DATALINK_HW_TOC_LINKUTIL_H_
#define __DATALINK_HW_TOC_LINKUTIL_H_

#include <omnetpp.h>

using namespace omnetpp;

class Toc_LinkUtil : public cSimpleModule
{
  private:
    long numReceived;
    cOutVector LinkUtil;
    simtime_t frame_time;

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif
