#include "Tic_frame.h"
Define_Module(Tic_frame);
void Tic_frame::initialize()
{
    timeout_time = 2;
    frame_time = 0.1;
    timeout_msg = new cMessage("timeout!");
    frame_msg = new cMessage("frame ready!");

    EV << "Sending Initial Message!\n";
    cMessage *msg = new cMessage("Tic to Toc Initial Message");
    send(msg, "portOut");

    scheduleAt(simTime()+timeout_time, timeout_msg);} //Schedules a self-message to perform timeout

void Tic_frame::handleMessage(cMessage *msg)
{
    if (msg == timeout_msg){
        EV << "Timeout! Resending.\n";
        cMessage *resent_msg = new cMessage("Resent Message");
        send(resent_msg,"portOut");
        scheduleAt(simTime()+timeout_time, timeout_msg);} //Schedules a self-message to perform timeout

    else if (msg == frame_msg){ // frame time
        EV << "Frame Ready!\n";
        send(tictoc_msg,"portOut");
        cancelEvent(frame_msg);
        scheduleAt(simTime()+timeout_time, timeout_msg);} //Schedules a self-message to perform timeout

    else{ // ACK received - wait for the frame to be ready
        EV << "ACK Received. Timer cancelled. Waiting for the frame to be ready. \n";
        cancelEvent(timeout_msg);
        scheduleAt(simTime()+frame_time, frame_msg); //Schedules a self-message to perform frame length
        cMessage *new_msg = new cMessage("New Message");
        tictoc_msg = new_msg;}
}
