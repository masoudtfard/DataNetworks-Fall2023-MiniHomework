#include "Toc.h"

Define_Module(Toc);

void Toc::handleMessage(cMessage *msg)
{
    if (uniform(0,1) > 0.5){
        EV << "Sending ACK from Toc.\n";
        cMessage *msg = new cMessage("ACK!");
        send(msg, "portOut");
    }
    else{// Message loss
       EV << "Message Lost!\n";
       bubble("Message Lost!");
       delete msg;
    }
}
