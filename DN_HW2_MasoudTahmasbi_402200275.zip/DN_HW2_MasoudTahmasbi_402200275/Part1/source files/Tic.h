#ifndef __DATALINK_HW_TIC_H_
#define __DATALINK_HW_TIC_H_

#include <omnetpp.h>
#include <string.h>

using namespace omnetpp;

class Tic : public cSimpleModule
{
  public:
    Tic() {
        timeout_msg = nullptr;
    }
  private:
    simtime_t timeout_time;  // timeout
    cMessage *timeout_msg;  // holds pointer to the timeout self-message
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif
