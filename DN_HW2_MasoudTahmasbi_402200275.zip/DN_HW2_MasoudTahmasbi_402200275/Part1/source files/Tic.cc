#include "Tic.h"

Define_Module(Tic);

void Tic::initialize()
{
    timeout_time = 2.0;
    timeout_msg = new cMessage("timeout!");

    EV << "Sending Initial Message!\n";
    cMessage *msg = new cMessage("Tic to Toc Initial Message");
    send(msg, "portOut");

    scheduleAt(simTime()+timeout_time, timeout_msg); //Schedules a self-message to perform timeout
}

void Tic::handleMessage(cMessage *msg)
{
    if (msg == timeout_msg){
        EV << "Timeout! Resending.\n";
        cMessage *resent_msg = new cMessage("Resent Message");
        send(resent_msg,"portOut");
        scheduleAt(simTime()+timeout_time, timeout_msg); //Schedules a self-message to perform timeout
    }
    else{ // ACK received
        EV << "ACK Received. Timer cancelled.\n";
        cancelEvent(timeout_msg);
        delete msg;

        // sending new message
        cMessage *new_msg = new cMessage("New Message");
        send(new_msg,"portOut");
        scheduleAt(simTime()+timeout_time, timeout_msg); //Schedules a self-message to perform timeout
    }
}
