#ifndef __MINIHW_HELLONET_HELLONET_NODE_H_
#define __MINIHW_HELLONET_HELLONET_NODE_H_

#include <omnetpp.h>

using namespace omnetpp;

class HelloNet_Node : public cSimpleModule
{
  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif
