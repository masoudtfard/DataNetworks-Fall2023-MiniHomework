#ifndef __DATALINK_HW_TOC_H_
#define __DATALINK_HW_TOC_H_

#include <omnetpp.h>

using namespace omnetpp;

class Toc : public cSimpleModule
{
  protected:
    virtual void handleMessage(cMessage *msg) override;
};

#endif
