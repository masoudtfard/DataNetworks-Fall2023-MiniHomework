#include "TicTocNode.h"

Define_Module(TicTocNode);

void TicTocNode::initialize()
{
    if(strcmp("Tic",getName())==0){
        cMessage *msg = new cMessage("Hello!");
        send(msg, "portOut");
    }
}

void TicTocNode::handleMessage(cMessage *msg)
{
    send(msg,"portOut");
}
