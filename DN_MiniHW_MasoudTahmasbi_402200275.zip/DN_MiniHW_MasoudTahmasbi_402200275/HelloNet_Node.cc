#include "HelloNet_Node.h"

Define_Module(HelloNet_Node);

void HelloNet_Node::initialize()
{
    if(strcmp("node1",getName())==0){
        cMessage *msg = new cMessage("Hello, OMNet++!");
        send(msg, "portOut");
    }
}

void HelloNet_Node::handleMessage(cMessage *msg)
{
    send(msg,"portOut");
}
