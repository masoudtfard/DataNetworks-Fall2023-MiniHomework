#include "Toc_LinkUtil.h"

Define_Module(Toc_LinkUtil);

void Toc_LinkUtil::initialize()
{
    numReceived = 0;
    frame_time = 0.1;
    WATCH(numReceived);
}

void Toc_LinkUtil::handleMessage(cMessage *msg)
{
    if (uniform(0,1) > 0.5){
        EV << "Sending ACK from Toc.\n";
        cMessage *msg = new cMessage("ACK!");
        send(msg, "portOut");
        numReceived++;
        LinkUtil.record(frame_time*numReceived/simTime());
        EV << "Received Messages: " << numReceived << "\n";

    }
    else{// Message loss
       EV << "Message Lost!\n";
       bubble("Message Lost!");
       delete msg;
    }
}
