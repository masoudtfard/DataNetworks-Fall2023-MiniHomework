#ifndef __DATALINK_HW_TIC_FRAME_H_
#define __DATALINK_HW_TIC_FRAME_H_

#include <omnetpp.h>

using namespace omnetpp;

class Tic_frame : public cSimpleModule
{
    public:
    Tic_frame() {
          timeout_msg = nullptr;
      }

    private:
      simtime_t timeout_time;
      simtime_t frame_time;

      cMessage *timeout_msg;
      cMessage *frame_msg;
      cMessage *tictoc_msg;

    protected:
      virtual void initialize() override;
      virtual void handleMessage(cMessage *msg) override;
};

#endif
